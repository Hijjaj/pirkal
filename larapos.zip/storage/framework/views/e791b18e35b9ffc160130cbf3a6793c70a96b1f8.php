 <?php $__env->startSection('content'); ?> <div class="content-header mt-5">
  <div class="container-fluid lead text-center">
    <h1 class="m-0 text-center" x-text="ct"></h1>
    <p x-text="ctndb"></p>
    <a class="btn btn-dark btn-lg" href="<?php echo e(route('categories.create')); ?>" x-text="cnct"></a> <?php if(isset($_SESSION['deleted'])): ?> <div class="row">
      <div class="alert alert-success"> Berhsail update data</div>
    </div> <?php endif; ?>
  </div>
</div>
<div class="content lead text-center">
  <div class="container-fluid"> <?php echo e($categories->links()); ?>

    <div class="row"> <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="col-sm-12 col-md-3 p-3 p-md-5 text-white">
        <div class="card">
          <div class="card-body bg-dark rounded">
          <svg class="bi bi-box" width="3em"
                            height="3em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5 8 5.961 14.154 3.5 8.186 1.113zM15 4.239l-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z" />
                        </svg>
            <br></br>
            <h5 class="card-title"><?php echo e($category->name); ?></h5>
            <br>
            <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <input onclick="return confirm('Are you sure to delete ' + ' ' + '');" type="submit" value="Delete" class="btn btn-danger btn-block">
            </form>
          </div>
        </div>
      </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php echo e($categories->links()); ?>

    </div>
  </div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\larapos\resources\views/categories/index.blade.php ENDPATH**/ ?>