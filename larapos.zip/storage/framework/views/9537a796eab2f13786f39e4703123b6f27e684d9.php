 <?php $__env->startSection('content'); ?> <div class="content-header mt-5">
  <div class="container lead text-center">
    <h1 x-text="pd" class="m-0 text-dark text-center">Produck</h1>
    <p x-text="dbps">Data Produk</p>
    <a class="btn btn-dark btn-lg" x-text="cnpdt" href="<?php echo e(route('products.create')); ?>"> Buat Menu Baru </a>
  </div>
</div>
<div class="content">
  <div class="container-fluid lead text-center"> <?php echo e($products->links()); ?>

    <div class="row"> <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="col-sm-12 col-md-3 lead text-center text-white p-3 p-md-5">
        <div class="card">
          <div class="card-body rounded-lg bg-dark">
          <svg class="bi bi-bag" width="3em"
                            height="3em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M14 5H2v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V5zM1 4v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4H1z" />
                            <path d="M8 1.5A2.5 2.5 0 0 0 5.5 4h-1a3.5 3.5 0 1 1 7 0h-1A2.5 2.5 0 0 0 8 1.5z" />
                        </svg>
            <br></br>
            <h5 class="card-title"><?php echo e($product->name); ?></h5>
            <p class="card-text"> <?php echo e($product->get_extract); ?></p>
            <br>
            <a class="btn btn-warning btn-block" href="<?php echo e(route('products.edit', $product)); ?>"> Edit </a>
            <br>
            <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <input onclick="return confirm('Delete Product ?? ' + '');" type="submit" value="Delete" class="btn btn-danger btn-block">
            </form>
          </div>
        </div>
      </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div> <?php echo e($products->links()); ?>

  </div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\larapos\resources\views/products/index.blade.php ENDPATH**/ ?>