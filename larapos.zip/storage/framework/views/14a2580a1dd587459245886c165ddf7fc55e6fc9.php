 <?php $__env->startSection('content'); ?><div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-12"><br>
                <h1 class="title text-dark"><center><b>KASIR</b></center></h1>
            </div>
            <div class="col-12 text-left">
                <h5>Pendapatan: <strong>Rp.<?php echo e($totalSalesPerDay); ?></strong></h5>
            </div>
        </div> <?php if(session('created')): ?><div class="row">
            <div class="col-12">
                <div class="alert alert-success"> Transaksi Berhasil</div>
            </div>
        </div> <?php endif; ?>
    </div>
</div>
<div class="content">
    <div class="container-fluid lead">
        <div class="row">
            <div class="col-md-6">
                <div class="card card-dark">
                    <div class="card-body">
                        <div id="js-requests-messages"></div> <?php if($errors->any()): ?><div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> - <?php echo e($error); ?> <br> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div> <?php endif; ?><form
                            method="post" action="#" id="createSaleForm">
                            <div class="form-group"> <label for="rfc"><b>Customer</b></label> <select id="rfc" name="rfc"
                                    class="form-control">
                                    <option value="">Pilih Customer</option> <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option
                                        value="<?php echo e($client->rfc); ?>"> <?php echo e($client->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select></div>
                            <div class="form-group">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Menu</th>
                                            <th>Jumlah</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody id="cartTable"></tbody>
                                </table>
                            </div>
                            <div class="form-group text-right">
                                <h5>TOTAL : <b>Rp.<span id="cartTotal" class="text-bold">0</span></b></h5>
                            </div> <?php echo csrf_field(); ?> <button type="submit" class="btn btn-dark btn-block btn-lg">Transaksi
                            </button> <input type="hidden" id="user-id" value="<?php echo e(Auth::user()->id); ?>">
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-dark text-light">
                    <div class="card-header text-light">
                        <h3 class="card-title"><b>List Menu</b></h3>
                    </div>
                    <div class="card-body table-responsive p-0 text-light" style="height: 300px;">
                        <table class="table table-head-fixed text-nowrap text-light">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Menu</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="products-table"> <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
                                    <td><?php echo e($product->product_id); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td> <button class="btn btn-success btn-sm" data-name="<?php echo e($product->name); ?>"
                                            data-price="<?php echo e($product->price); ?>" data-id="<?php echo e($product->product_id); ?>"
                                            data-left="<?php echo e($product->product_left); ?>"> <i class="fas fa-plus"></i> Add
                                        </button></td>
                                </tr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\larapos\resources\views/sales/create.blade.php ENDPATH**/ ?>