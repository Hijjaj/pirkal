@extends('layouts.app') @section('content') <div class="masthead-followup row m-0 text-center lead">
    
